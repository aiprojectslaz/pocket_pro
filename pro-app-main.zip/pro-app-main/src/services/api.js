// src/services/api.js
import axios from 'axios';

const apiClient = axios.create({
  baseURL: 'http://localhost:1337/api', // Replace with your Strapi URL
  headers: {
    'Content-Type': 'application/json',
  },
});

// Automatically add the token to the headers if available
apiClient.interceptors.request.use((config) => {
    const token = localStorage.getItem('authToken');
    if (token) {
      config.headers.Authorization = `Bearer ${token}`;
    }
    return config;
  }, (error) => {
    return Promise.reject(error);
  });
  
export default {
  // Fetch a specific procedure by ID
  getProcedure(id) {
    return apiClient.get(`/procedures/${id}`);
  },
  
  // Fetch all procedures
  getProcedures() {
    return apiClient.get('/procedures');
  },

  // Fetch definitions
  getDefinitions() {
    return apiClient.get('/definitions');
  },  getProcedures() {
    return api.get('/procedures');
  },
  getSubProcedures(){
    return apiClient.get('/sub-procedures')
  },
  getSubRoles(){
    return apiClient.get('/procedure-roles')
  },
  getSubRoles(){
    return apiClient.get('/procedure-roles')
  },getAppendices(){
    return apiClient.get('/appendices')
  },
  getMainRoles(){
    return apiClient.get('/main-roles')
  },
  getProcedureById(id) {
    return api.get(`/procedures/${id}`);
  },

  
  // Add other API calls as needed
};





