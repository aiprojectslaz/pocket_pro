import { createRouter, createWebHistory } from 'vue-router'
//import HeaderComponent from '@/components/Header.vue';
//import FooterComponent from '@/components/Footer.vue';
import HomeView from '@/views/HomeView.vue';
import ProceduresList from '@/components/ProceduresList.vue';
import ProcedureItem from '@/components/ProcedureItem.vue';
import MainRoleItem from '@/components/MainRoleItem.vue';
import SubRolesItem from '@/components/SubRolesItem.vue';
import SubProcedureItem from '@/components/SubProcedureItem.vue';
import DefinitionItem from '@/components/DefinitionItem.vue';
import AppendixItem from '@/components/AppendixItem.vue';
import SearchResultsView from '@/views/SearchResultsView.vue';
import Quiz from '@/components/Quiz.vue';
import AdminDashboard from '@/views/AdminDashboard.vue';
import { getAuthState } from '@/utils/auth'; // Assume you have a utility function for authentication
import Modal from '@/components/Modal.vue';

//import api from '@/services/api';
//import axios from 'axios';

const routes = [
  {
    path: '/',
    name: 'home',
    component: HomeView,
  },
  {
    path: '/procedure-list',
    name: 'procedures-list',
    component: ProceduresList,
  },
  {
    path: '/procedure/:id',
    name: 'procedure-item',
    component: ProcedureItem,
    props: true, // Pass route params as props
  },
  {
    path: '/mainRole/:id',
    name: 'mainRole-item',
    component: MainRoleItem,

  },
  {
    path: '/definition/:id',
    name: 'definition-item',
    component: DefinitionItem,
    props: true, // Pass route params as props
  },
  {
    path: '/appendix/:id',
    name: 'appendix-item',
    component: AppendixItem,
    props: true, // Pass route params as props
  },
  {
    path: '/subProcedure/:id',
    name: 'subProcedure-item',
    component: SubProcedureItem,

  },
  {
    path: '/subRole/:id',
    name: 'subRole-item',
    component: SubRolesItem,
  },
  {
    path: '/quizzes',
    name: 'quizzes',
    component:  Quiz,
  },
  {
    path: '/users',
    name: 'users',
    component: () => import('../views/UsersView.vue') // will call this User Account 
  },
  { 
    path: '/', 
    name: 'home', 
    component: () => import('../views/HomeView.vue') // home page - not set up yet
  },  
  { 
    path: '/register', 
    name: 'register', 
    component: () => import('../views/RegisterView.vue') // signup page
  },
  { 
    path: '/login', 
    name: 'login', 
    component: () => import('../views/LoginView.vue') // will call this Account/Login
  },
  { 
    path: '/logout', 
    name: 'logout', 
    component: () => import('../views/LoginView.vue') 
  },
  {
    path: '/search',
    name: 'search-results',
    component: SearchResultsView,
  },
  {
    path: '/contact',
    name: 'contact',
    component: () => import('../views/ContactView.vue') //lives in the footer
  },
  {
    path: '/request-a-demo',
    name: 'request-a-demo',
    component: () => import('../views/RequestDemo.vue') //lives in the footer
  },
  {
    path: '/bookmarks',
    name: 'bookmarks',
    component: () => import('../views/BookmarksView.vue') //visible with login
  },
  {
    path: '/about',
    name: 'about',
    component: () => import('../views/AboutView.vue') //lives in the footer
  },
  {
    path: '/terms',
    name: 'terms',
    component: () => import('../views/TermsView.vue') //lives in the footer
  },
  {
    path: '/privacy',
    name: 'privacy',
    component: () => import('../views/PrivacyView.vue')//lives in the footer
  },
  {
    path: '/admin',
    name: 'admin',
    component: AdminDashboard,
    meta: { requiresAuth: true, isAdmin: true }
  },
  {
    path: '/modal',
    name: 'modal',
    component: Modal,
    meta: { requiresAuth: true, isAdmin: true }
  },

  // Add additional routes here as needed

];

const router = createRouter({
  history: createWebHistory(),
  routes,
});

// Navigation guard

router.beforeEach((to, from, next) => {
  const authState = getAuthState();

  if (to.matched.some(record => record.meta.requiresAuth)) {
    if (!authState.isLoggedIn) {
      next('/login'); // Redirect to login if not logged in
    } else if (to.matched.some(record => record.meta.isAdmin) && !authState.isAdmin) {
      next('/'); // Redirect to home if not admin
    } else {
      next(); // Proceed to the route
    }
  } else {
    next(); // Proceed if no auth required
  }
});


export default router;