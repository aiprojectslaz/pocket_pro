<script setup>
import { RouterLink, RouterView } from 'vue-router'

</script>

<template>
<header class="app-header  text-white py-2">

<!-- Navbar -->
<nav class="app-header navbar navbar-expand-lg navbar-dark ">
  <!-- Container wrapper -->
  <div class="container-fluid">

    <!-- Navbar brand -->
      <RouterLink to="/" class="navbar-brand mt-2 mt-lg-0"><img src="@/assets/logos/Logo1_BlueBG_cropped.png" height="40" alt="MDB Logo" loading="lazy" /></RouterLink>

      <!-- Search Bar-->
      <div class="search-bar d-flex" v-if="authState.isLoggedIn">
        <input type="text" v-model="searchQuery" @keyup.enter="search" class="form-control me-2" placeholder="Search procedures..."/>
        <a @click="performSearch" class="btn d-flex align-items-center hidden-arrow" href="#" role="button" aria-expanded="false">
          <fa icon="search" inverse/>
        </a>
      </div>
      <!-- Search Bar -->

    <!-- Toggle button -->
    <!-- Menu Icon -->
    <button class="navbar-toggler" type="button" data-mdb-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
      
      <!-- Show this dropdown only if the user is logged in -->
      <div class="dropdown" v-if="authState.isLoggedIn">
        <a class="btn dropdown-toggle d-flex align-items-center hidden-arrow" href="#" role="button" id="navbarDropdownMenuAvatar" data-bs-toggle="dropdown" aria-expanded="false">
          <fa icon="bars" inverse />
        </a>
        <ul class="dropdown-menu dropdown-menu-end" aria-labelledby="dropdownMenuButton1">
          <li class="dropdown-item"><RouterLink to="/" class="nav-link">Home</RouterLink></li>
          <li class="dropdown-item"><RouterLink to="/procedure-list" class="nav-link">Procedures</RouterLink></li>
          <li class="dropdown-item"><RouterLink to="/bookmarks" class="nav-link">Bookmarks</RouterLink></li>
          <li class="dropdown-item"><RouterLink to="/quizzes" class="nav-link">Quiz</RouterLink></li>
          <li><hr class="dropdown-divider"></li>
          <li><a class="dropdown-item" href="#">My profile</a></li>
          <li><a class="dropdown-item" href="#">Settings</a></li>
          <li class="dropdown-item" @click="logout"><RouterLink to="/logout" class="nav-link">Logout</RouterLink></li>
        </ul>
      </div>
      
      <!-- Show this simple Login link if the user is not logged in -->
      <div v-else class="d-flex align-items-center">
        <RouterLink to="/login" class="nav-link">Login</RouterLink>
      </div>
    </button>
    <!-- Menu Icon -->

    <!-- Collapsible wrapper -->
    <div class="collapse navbar-collapse" id="navbarSupportedContent">

      <!-- Left links -->
      <ul class="navbar-nav me-auto mb-2 mb-lg-0">
        <li class="nav-item" v-if="authState.isLoggedIn"><RouterLink to="/" class="nav-link text-white">Home</RouterLink></li>
        <li class="nav-item" v-if="authState.isLoggedIn"><RouterLink to="/procedure-list" class="nav-link text-white">Procedures</RouterLink></li>
        <li class="nav-item" v-if="authState.isLoggedIn"><RouterLink to="/bookmarks" class="nav-link text-white">Bookmarks</RouterLink></li>
        <li class="nav-item" v-if="authState.isLoggedIn"><RouterLink to="/quizzes" class="nav-link text-white">Quiz</RouterLink></li>
        <li class="nav-item" v-if="authState.isLoggedIn"><RouterLink to="/admin" class="nav-link text-white">Dashboard</RouterLink></li>
      </ul>
      <!-- Left links -->

      <!-- Right elements -->
      <div class="d-flex align-items-center">

        <!-- Account Button (Only visible if logged in) -->
        <div v-if="authState.isLoggedIn">
          <div class="dropdown">
            <button class="btn btn-secondary btn-sm dropdown-toggle" type="button" id="dropdownMenuButton1" data-bs-toggle="dropdown" aria-expanded="false">
              Account
            </button>
            <ul class="dropdown-menu dropdown-menu-end" aria-labelledby="dropdownMenuButton1">
              <li><a class="dropdown-item" href="#">My profile</a></li>
              <li><a class="dropdown-item" href="#">Settings</a></li>
              <li><hr class="dropdown-divider"></li>
              <li class="dropdown-item" @click="logout">
                <RouterLink to="/logout" class="nav-link">Logout</RouterLink>
              </li>
            </ul>
          </div>
        </div>

        <!-- Login Link (Only visible if not logged in) -->
          <div v-else class="d-flex align-items-center">
            <RouterLink to="/login" class="nav-link">Login</RouterLink>
          </div>

      </div>
      <!-- Right elements --> 
   </div>
    <!-- Collapsible wrapper -->
  </div>
  <!-- Container wrapper -->
</nav>
<!-- Navbar -->
    
  </header>
</template>



<script>
import axios from 'axios';
import api from '@/services/api';
import qs from 'qs'; // Import qs at the top
  import { mapState } from 'vuex';
  import { authState } from '@/store/authState';
  import SearchResults from '@/views/SearchResultsView.vue';

  export default {
    data() {
      return {
        searchQuery: '',  // Bind this to the search input
      };
    },
    computed: {
      isLoggedIn() {
        return authState.isLoggedIn;
      },
      ...mapState({
        isLoggedIn: state => !!state.jwt // don't think this is needed any more!!
      })
    },
    mounted() {
      if (authState.jwt) {
        // Optionally, you can verify the token's validity by making a request to the backend
        console.log('User is already logged in');
      }
    },
    methods: {
      logout() {
        authState.logout();
        this.$store.dispatch('logout');
        this.$router.push('/');
      },
      async performSearch() {
      // Your search logic here
      console.log('Searching for:', this.searchQuery);
      try {
         // Call fetchProcedures with the search query
        await this.fetchProcedures(this.searchQuery);
        // Redirect to the search results page with the query as a URL parameter
        this.$router.push({ name: 'SearchResults', query: { q: this.searchQuery } });
        } catch (error) {
        console.error('Error performing search:', error);
        }
      },
      async fetchProcedures(query) {
        try {
          // Build the query string
          const queryString = qs.stringify({
            filters: {
              $or: [
                { name: { $contains: query, } },
                { procedure_number: { $contains: query } },
                { procedure_info: { $contains: query } },
                { rationale: { $contains: query } },
                { 'appendices.title': { $contains: query } },
                { 'appendices.description': { $contains: query } },
                { 'definitions.term': { $contains: query } },
                { 'definitions.definition': { $contains: query } },
                { 'sub_procedures.name': { $contains: query } },
                { 'sub_procedures.description': { $contains: query } }
              ]
            }
          }, { encodeValuesOnly: true });

          // Make the API request
          const response = await axios.get(`http://localhost:1337/api/procedures?populate=definitions,sub_procedures,appendices&${queryString}`);
          
          // Handle the response data
          console.log('Search results:', response.data);
          // Process the data as needed
          // For example, update a data property or store in Vuex
          
        } catch (error) {
          console.error('Error fetching procedures:', error);
        }
      }
    }
  };
</script>
<!-- -->

<style scoped lang="scss">
  .app-header {
    background-color: #113065; // Background color for the header
    //padding: 10px 20px; // Padding for the header

    .logo img {
      max-height: 75px; // Adjust logo size
    }

  nav{
    background-color: #113065; // Background color for the navbar
    }

    .main-nav .nav-link {
      margin-right: 15px; // Space out navigation links
      &:hover {
        text-decoration: underline;
      }
    }

    .search-bar {
      .form-control {
        width: auto; // Adjust input width
        margin-right: 10px; // Space between input and button
      }

      .btn {
        padding: 0.375rem 0.75rem; // Adjust button padding
      }
    }

    /*@media (max-width: 768px) {
      .wrapper {
        flex-direction: column;
        align-items: flex-start;

        .search-bar {
          margin-top: 10px;
          width: 100%;
        }
      }
    }*/
  }
</style>
