<template>
<div class="buttons-row container py-4">
  <!-- Left-aligned buttons -->
  <div class="left-buttons">
    <button @click="goBack" class="btn btn-secondary btn-sm ">Back</button>
  </div>
</div>
  <div class="login-container container mt-5">
    <h2 class="text-center mb-4">Account Login</h2>
    <form @submit.prevent="loginUser" class="p-4 shadow-sm rounded bg-light">

      <!-- Email Field -->
      <div class="form-group mb-3">
        <label for="email" class="form-label">Email:</label>
        <input type="email" v-model="email" id="email" class="form-control" placeholder="Enter your email" required>
      </div>

      <!-- Password Field -->
      <div class="form-group mb-4">
        <label for="password" class="form-label">Password:</label>
        <input 
          type="password" 
          v-model="password" 
          id="password" 
          class="form-control" 
          placeholder="Enter your password" 
          required>
      </div>

        <!-- 2 column grid layout for inline styling -->
        <div class="row mb-4">
          <div class="col d-flex justify-content-center">
            <!-- Checkbox -->
            <div class="form-check">
              <input class="form-check-input" type="checkbox" value="" id="form1Example3" checked />
              <label class="form-check-label" for="form1Example3"> Remember me </label>
            </div>
          </div>

          <div class="col">
            <!-- Simple link -->
            <a href="#!">Forgot password?</a>
          </div>
        </div>

      <!-- Submit Button -->
      <button type="submit" class="btn btn-primary w-100">Sign In</button>
    </form>

    <!-- Register Link -->
    <div class="register-container text-center mt-3">
      <RouterLink to="/register" class="text-primary">Don't have an account? Register</RouterLink>
    </div>
  </div>
</template>


<script>
import api from '@/services/api';
import axios from 'axios';
import { mapActions } from 'vuex';
import { authState } from '@/store/authState';

export default {
  data() {
    return {
      username: '',
      email: '',
      password: '',
      favorites: [],
    };
  },
  methods: {
    goBack() {
      this.$router.go(-1);
    },
    async loginUser() {
      console.log('Login button clicked');
      try {
        // Request API.

        const response = await axios.post('http://localhost:1337/api/auth/local', {
          identifier: this.email,
          password: this.password,
        });

        // If you need the user data
            const user = response.data.user;
            const favorites = user.favorites
            console.log('User profile:', user);
            console.log('User favorites:', favorites);

        // Extract the JWT from the response
        const jwt = response.data.jwt;
        const username = response.data.user.username;

        // Log success message and JWT token
        console.log('Login Success!');
        console.log('Username:', username);
        console.log('JWT Token:', jwt);

        // Set the JWT in authState (or your store)
        authState.setJwt(jwt); 

        // Save JWT to localStorage to persist the session
        localStorage.setItem('jwt', jwt);
        localStorage.setItem('username', username);

        // Redirect to home or another page
        this.$router.push('/procedure-list');
      } catch (error) {
        // Handle error and log the response
        console.error('Login failed:', error.response);
        // Optionally, set an error message to display to the user
        this.errorMessage = 'Login failed. Please check your credentials and try again.';
      }
    }
  }

};
</script>


<style scoped lang="scss">
.login-container {
  max-width: 400px;
  margin: 0 auto;

  .form-group {
    margin-bottom: 1rem;
  }

  .btn {
    font-size: 1.2rem;
  }

  .register-container {
    margin-top: 1rem;
    a {
      text-decoration: none;
    }
  }
}
</style>

